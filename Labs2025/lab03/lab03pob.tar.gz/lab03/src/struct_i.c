void print_structI(StructI* s) {
    printf("StructI: value=%d\n", s->valueI);
}
