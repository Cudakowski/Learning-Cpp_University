void print_structB(StructB* s) {
    printf("StructB: value=%d\n", s->valueB);
}
