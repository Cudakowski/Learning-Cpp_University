void print_structL(StructL* s) {
    printf("StructL: value=%d\n", s->valueL);
}
