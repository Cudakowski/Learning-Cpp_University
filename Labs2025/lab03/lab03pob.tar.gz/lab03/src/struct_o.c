void print_structO(StructO* s) {
    printf("StructO: value=%d\n", s->valueO);
}
