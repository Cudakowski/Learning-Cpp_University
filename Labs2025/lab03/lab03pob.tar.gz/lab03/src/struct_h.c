void print_structH(StructH* s) {
    printf("StructH: value=%d\n", s->valueH);
}
