void print_structE(StructE* s) {
    printf("StructE: value=%d\n", s->valueE);
}
