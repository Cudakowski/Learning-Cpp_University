void print_structN(StructN* s) {
    printf("StructN: value=%d\n", s->valueN);
}
