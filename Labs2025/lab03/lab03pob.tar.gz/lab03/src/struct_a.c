void print_structA(StructA* s) {
    printf("StructA: value=%d\n", s->valueA);
}
