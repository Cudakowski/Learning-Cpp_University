void print_structF(StructF* s) {
    printf("StructF: value=%d\n", s->valueF);
}
