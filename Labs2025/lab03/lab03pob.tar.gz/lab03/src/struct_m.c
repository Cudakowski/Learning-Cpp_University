void print_structM(StructM* s) {
    printf("StructM: value=%d\n", s->valueM);
}
