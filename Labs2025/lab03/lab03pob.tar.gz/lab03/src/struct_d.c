void print_structD(StructD* s) {
    printf("StructD: value=%d\n", s->valueD);
}
