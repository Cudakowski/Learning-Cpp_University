void print_structK(StructK* s) {
    printf("StructK: value=%d\n", s->valueK);
}
