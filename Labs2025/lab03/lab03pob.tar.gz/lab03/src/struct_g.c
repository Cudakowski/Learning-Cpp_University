void print_structG(StructG* s) {
    printf("StructG: value=%d\n", s->valueG);
}
