void print_structC(StructC* s) {
    printf("StructC: value=%d\n", s->valueC);
}
