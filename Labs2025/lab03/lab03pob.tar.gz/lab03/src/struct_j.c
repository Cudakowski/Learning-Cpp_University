void print_structJ(StructJ* s) {
    printf("StructJ: value=%d\n", s->valueJ);
}
