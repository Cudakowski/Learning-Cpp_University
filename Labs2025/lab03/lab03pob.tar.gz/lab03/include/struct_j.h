void print_structJ(StructJ* s);
