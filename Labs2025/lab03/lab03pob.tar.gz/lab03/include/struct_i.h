void print_structI(StructI* s);
