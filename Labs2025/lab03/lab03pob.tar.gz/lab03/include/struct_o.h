void print_structO(StructO* s);
