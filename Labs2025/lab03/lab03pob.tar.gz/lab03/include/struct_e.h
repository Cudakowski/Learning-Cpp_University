void print_structE(StructE* s);
