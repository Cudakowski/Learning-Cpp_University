void print_structM(StructM* s);
