void print_structA(StructA* s);
