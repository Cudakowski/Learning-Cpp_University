void print_structB(StructB* s);
