void print_structH(StructH* s);
