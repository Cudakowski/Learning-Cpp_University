void print_structK(StructK* s);
