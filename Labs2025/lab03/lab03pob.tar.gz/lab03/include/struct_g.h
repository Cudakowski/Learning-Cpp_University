void print_structG(StructG* s);
