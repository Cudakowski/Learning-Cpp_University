void print_structL(StructL* s);
