void print_structN(StructN* s);
