void print_structF(StructF* s);
