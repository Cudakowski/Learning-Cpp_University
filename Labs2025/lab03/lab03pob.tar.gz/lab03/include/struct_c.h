void print_structC(StructC* s);
