void print_structD(StructD* s);
