#ifndef MY_LIBRARY_H
#define MY_LIBRARY_H

#include <iostream>

#define PROJECTPATH __FILE__

void PrintName(const char *name);

void PrintInfo(const char *info);

#endif