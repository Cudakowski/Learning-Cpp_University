#include "MyLibrary.h"

void PrintName(const char *name)
{
    std::cout << "[INFO]:: Name: " << name << '\n';
}


void PrintInfo(const char *info)
{
    std::cout << "[INFO]:: " << info << '\n';
}