#include "Shop.h"


Shop::Shop()
{

}

Shop::Shop(const Shop &sh) : vec(sh.vec)
{

}

std::ostream &operator<<(std::ostream &os, Shop const &shop)
{
    os << "---\n";
    os << "# Zawartosc/sklad:\n";
    for(int i{}; i<shop.vec.size() ; ++i )
    {
        os << shop.vec[i];
    }
    os << "---\n";
    
    return os;
}

void Shop::Remove()
{
    if(vec.size()<1)
    {
        std::cout << "BLAD: Pusto !\n";
        return;
    }

    vec.pop_back();
}

void Shop::Add(Product a)
{
    vec.push_back(a);
}


Product &Shop::operator[](int a)
{
    return vec[a];
}

Shop Shop::operator-(int a)
{
    Shop x=*this;
    for(int i{};i<x.vec.size();++i)
    {
        x[i]=x[i]-a;
    }
    return x;
}

Shop Shop::operator+(int a)
{
    Shop x=*this;
    for(int i{};i<x.vec.size();++i)
    {
        x[i]=x[i]+a;
    }
    return x;
}

Shop Shop::operator*(int a)
{
    Shop x=*this;
    for(int i{};i<x.vec.size();++i)
    {
        x[i]=x[i]*a;
    }
    return x;
}

Shop Shop::operator+(Shop sh)
{
    Shop x=*this;
    for(int i{};i<sh.vec.size();++i)
    {
        x.Add(sh[i]);
    }
    return x;
}

void Shop::Clear()
{
    vec.clear();
}
