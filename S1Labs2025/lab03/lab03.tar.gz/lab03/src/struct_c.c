#include "../include/struct_c.h"
#include <stdio.h>
void print_structC(StructC* s) {
    printf("StructC: value=%d\n", s->valueC);
}
