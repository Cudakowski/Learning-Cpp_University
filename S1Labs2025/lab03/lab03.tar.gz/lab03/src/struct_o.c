#include "../include/struct_o.h"
#include <stdio.h>
void print_structO(StructO* s) {
    printf("StructO: value=%d\n", s->valueO);
}
