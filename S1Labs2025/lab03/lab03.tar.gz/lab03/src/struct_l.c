#include "../include/struct_l.h"
#include <stdio.h>
void print_structL(StructL* s) {
    printf("StructL: value=%d\n", s->valueL);
}
