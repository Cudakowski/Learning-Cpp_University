#include "../include/struct_h.h"
#include <stdio.h>
void print_structH(StructH* s) {
    printf("StructH: value=%d\n", s->valueH);
}
