#include "../include/struct_k.h"
#include <stdio.h>
void print_structK(StructK* s) {
    printf("StructK: value=%d\n", s->valueK);
}
