#include "../include/struct_b.h"
#include <stdio.h>
void print_structB(StructB* s) {
    printf("StructB: value=%d\n", s->valueB);
}
