#include "../include/struct_m.h"
#include <stdio.h>
void print_structM(StructM* s) {
    printf("StructM: value=%d\n", s->valueM);
}
